package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.servlet.ModelAndView;


public class CourseDB extends DBConnection {
	
	public static void InsertCourse(int CourseID ,String CourseName , String Description )
	{
	
	PreparedStatement preparedStatement=null;
	DBConnection.connection();
	String host= "jdbc:mysql://localhost/Gamedb";
	String UserName="root";
	String Pass="";
	Connection connect=null;

		    	  try{
		    		  
		    	  
						connect =DriverManager.getConnection(host,UserName,Pass);
						 preparedStatement = connect
						          .prepareStatement("INSERT INTO  course (CourseID,CourseName,Description) VALUES ( ? , ?, ?)");
						      preparedStatement.setInt(1, CourseID);
						      preparedStatement.setString(2, CourseName);
						      preparedStatement.setString(3, Description);
						    
						      preparedStatement.executeUpdate();
						      preparedStatement.close();
						      connect.close();
					}catch (SQLException e){
						e.printStackTrace();
	}
	
	}
	
	
	public static void RetrieveCourses (List Courses)
	{
	
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		Connection connect=null;
		DBConnection.connection();
		String host= "jdbc:mysql://localhost/DataBase";
		String UserName="root";
		String Pass="";
		try{
			Connection connect1 =(Connection) DriverManager.getConnection(host,UserName,Pass);
			preparedStatement = connect1
			          .prepareStatement("SELECT CourseName from course  ");
			      resultSet = preparedStatement.executeQuery();
			      ResultSetMetaData rsmd = (ResultSetMetaData) resultSet.getMetaData();
			      int columnsNumber = rsmd.getColumnCount();
			     // System.out.println(columnsNumber);
			      while (resultSet.next()) {
			          for (int i = 1; i <= columnsNumber; i+=6) {
			              String columnValue = resultSet.getString(i); 
			              Courses.add(columnValue);
			          }
			       
			      }

		}catch (SQLException e){
			e.printStackTrace();
		}
	  		
	  	}
	
}


