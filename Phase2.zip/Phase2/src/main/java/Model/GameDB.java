package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class GameDB extends DBConnection{
	static public void  InsertGame (int CourseID , String GameName , int NumberOfQuestion){
		String host="jdbc:mysql://localhost/GameDB";
		String userName="root";
		String pass = "";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Connection is established successfully with the servaaaaaae");
			Connection connection = (Connection) DriverManager.getConnection(host,userName,pass);

	    
		 PreparedStatement stmt = (PreparedStatement) connection.prepareStatement("insert into Game (Course_ID, Game_Name, Number_Of_Question) VALUES (?, ?, ?)");
		 
		    stmt.setInt(1, CourseID);
		    stmt.setString(2, GameName);
		    stmt.setInt(3, NumberOfQuestion);
		   
		    
		   stmt.executeUpdate();
		   
			stmt.close();
		    connection.close();


		}
	    catch (Exception e) {
			System.err.println("Error"+e.getMessage());
		}

		}

}
