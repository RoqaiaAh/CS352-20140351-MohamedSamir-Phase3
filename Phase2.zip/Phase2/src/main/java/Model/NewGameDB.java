package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class NewGameDB extends DBConnection{

	static public void  InsertNewGame (String GameName , String Question , String CorrectAnswer){
	String host="jdbc:mysql://localhost/GameDB";
	String userName="root";
	String pass = "";
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Connection is established successfully with the servaaaaaae");
		Connection connection = (Connection) DriverManager.getConnection(host,userName,pass);

    
	 PreparedStatement stmt = (PreparedStatement) connection.prepareStatement("insert into add_new_game (Game_Name, Question, Correct_Answer) VALUES (?, ?, ?)");
	 
	    stmt.setString(1, GameName);
	    stmt.setString(2, Question);
	    stmt.setString(3, CorrectAnswer);
	   
	    
	   stmt.executeUpdate();
	   
		stmt.close();
	    connection.close();


	}
    catch (Exception e) {
		System.err.println("Error"+e.getMessage());
	}

	}

}
