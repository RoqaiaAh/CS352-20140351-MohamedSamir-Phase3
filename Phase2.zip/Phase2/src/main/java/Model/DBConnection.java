package Model;



public class DBConnection {
	
	public static void connection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Connection is established successfully with the serve");
			
		} catch (Exception e) {
			System.err.println("Error"+e.getMessage());
		} 
	}
	}


