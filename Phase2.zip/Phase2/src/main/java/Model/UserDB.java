package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import Entity.User;

public class UserDB extends DBConnection{
	public static void InsertUser(String name , String password , String email,String type )
	{
		
		DBConnection.connection();
		String host="jdbc:mysql://localhost/userdb";
		String userName="root";
		String pass = "";
		try {
			Connection connection = (Connection) DriverManager.getConnection(host,userName,pass);
			 PreparedStatement stmt = (PreparedStatement) connection.prepareStatement("insert into user (User_Name, User_Password, User_Email , User_Type) VALUES (?, ?, ? , ?)");
			 
			    stmt.setString(1, name);
			    stmt.setString(2, password);
			    stmt.setString(3, email);
			    stmt.setString(4,type);
			   
			    
			   stmt.executeUpdate();
			   
				stmt.close();
			    connection.close();
			    
			    
		} catch (Exception e) {
			System.err.println("Error"+e.getMessage());
		}
		
	}
	
	
	public static ArrayList<User> getAllUsers() throws ClassNotFoundException, SQLException {
		DBConnection.connection();
		String host="jdbc:mysql://localhost/userdb";
		String userName="root";
		String pass = "";
		
			Connection connection = (Connection) DriverManager.getConnection(host,userName,pass);
			    Statement stm;
			    stm = (Statement) connection.createStatement();		
		   
			    ResultSet rst;
			    rst = stm.executeQuery("Select * From user");
			  
			    
			    ArrayList<User> UserList = new ArrayList<User>();
			    while (rst.next()) {
			        User u = new User(rst.getString("User_Name"), rst.getString("User_Password"),rst.getString("User_Email"),rst.getString("User_Type"));
			        UserList.add(u);
			    }

			    return UserList;
	}
	
	

}
