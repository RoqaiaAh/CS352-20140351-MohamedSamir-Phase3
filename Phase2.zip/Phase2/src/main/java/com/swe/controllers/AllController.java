package com.swe.controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import Model.GameDB;
import Model.NewGameDB;

import Entity.User;
import Model.CourseDB;
import Model.DBConnection;
import Model.UserDB;

/**
 * Purpose: Handle the interaction between the Model And The View  
 * @author Doaa Ghaleb , Roqaia Ahmed , Hagar Mohame , Ezzat Hany , Amr Almaz.
 * @version: 4.6.3
 */

@Controller
public class AllController {
	/**
	 * purpose : return a view to validate a login for an existing user.
	 * @param : No parameter
     * @return : Login view (Login.html)
     */
	
	@RequestMapping("/")
	public String LoginView(){
		
		return "Login";
		

	}
	/**
	 * purpose :  validate a login for an existing user.
	 * @param : Name and Password to check if it's exist in the User DB or Not.
     * @return : 
     * if it's exist as a student ->
     * then return the courses to start play games 
     * if it's exist as an a Teacher ->
     * then return the Teacher Profile with different functionality
     * if it's NOT exist ->
     * try to Re_Login 
     */
	
	@RequestMapping("/Result")
	public ModelAndView ViewRetrieveUser(
			@RequestParam("OldName")String name , 
			@RequestParam ("OldPassword") String password
	) throws ClassNotFoundException, SQLException
	{
	
		
		ArrayList<User> user = UserDB.getAllUsers();
		ModelAndView mv=new ModelAndView();
		int i=0;
		
		boolean flag=false;
		while (i<user.size())
				 
		{
			String Name = user.get(i).getName();
			String Pass=user.get(i).getPassword();
			String Type=user.get(i).getType();
			
			
			if(Name.equals(name) && Pass.equals(password))
			{
				
				//System.out.println("Found"+Name+name);
				flag=true;
				if(Type.equals("Teacher"))
				{
					mv.setViewName("TeacherProfile");
					break;
				}
				else
				{
					mv.setViewName("ViewCourses");
					break;
				}
				
			}
			else
			{
				//System.out.println(Name+name+Pass+password);
				i++;
				
			}
			

		}
		if(flag==false)
		{
			mv.setViewName("LoginError");
		}
	
		
		
		return mv;
		
	}
	
	/**
	 * purpose : return a registeration view .
	 * @param : No parameter
     * @return : Registeration view (Registeration.html)
     */

	@RequestMapping("/Registeration")
	public ModelAndView RegisterationView()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("Registeration");
		return mv;

	}
	/**
	 * purpose : Register a user and save it in a DB.
	 * @param : name , password , email , type.
     * @return : UserType view (UserType.html)
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
     */
	
	@RequestMapping("/UserType")
	public ModelAndView ViewInsertUser(
			@RequestParam("Name")String name , 
			@RequestParam ("Password") String password,
			@RequestParam ("Email") String email,
			@RequestParam ("Type") String type
			) throws ClassNotFoundException, SQLException
	{		
		ArrayList<User> user = UserDB.getAllUsers();
		ModelAndView mv=new ModelAndView();
		int i=0;
		for(i=0  ; i<user.size();i++)
				 
		{
			String Name = user.get(i).getName();
			String Pass=user.get(i).getPassword();
			if(Name.equals(name))
			{
				mv.setViewName("RegisterationError");
				return mv;
			
			}
		}
		UserDB.InsertUser(name, password, email,type);
		
		mv.setViewName("UserType");
		return mv;
	}

	
	/**
	 * purpose : create course , and save it in a Database.
	 * @param : CourseID (integer) , CourseName (String) , Description (String) 
	 * and get them from CreateCourse form , and save it in a Database.
	 * @return : if created return viewCourse form with the added course , 
	 * if the course is exist return Course is already exist form .
	 */
	
	@RequestMapping("/ViewCourses")
	public ModelAndView CourseView()
			
	{	
		List Courses= new ArrayList<String>();
		ModelAndView mv = new ModelAndView();
		CourseDB.RetrieveCourses(Courses);
		mv.setViewName("ViewCourses");
		mv.addObject("Courses",Courses);
	
		return mv;

	}
	/**
	 * purpose : return a view to a Teacher Profile with different functionality.
	 * @param : No parameter
	 * @return : Teacher Profile view (TeacherProfile.html)
	 */
	
	@RequestMapping("/TeacherProfile")
	public ModelAndView TeacherProfileView(
			@RequestParam("code")String code)
			
	{		   
		ModelAndView mv=new ModelAndView();
		if(code.equals("Teacher")||code.equals("TEACHER") )
		{
			mv.setViewName("TeacherProfile");
		}
		else
		{
			mv.setViewName("UserTypeError");
			
		}
		return mv;
		
			
	}
	
	/**
	 * purpose : return a view to create a course.
	 * @param : No parameter
	 * @return : Add course view (AddCourse.html)
	 */
	
	@RequestMapping("/AddCourse")
	public ModelAndView AddCourseView()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("AddCourse");
		return mv;
	}
	

	@RequestMapping("/ViewTeacherProfile")
	public ModelAndView TeacherProfileView()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("TeacherProfile");
		return mv;
	}

	/**
	 * purpose :  Add Course .
	 * @param : Course Id , Name , and description
	 * and check if it's exist in the Course DB or Not.
     * @return : 
     * if it's exist ->
     * then return the Course is already exist then try to Re_add Course
     * if it's not exist ->
     * then return the Courses with the added course.
     */
	
	@RequestMapping("/R")
	public ModelAndView ViewInsertCourse
	( 		@RequestParam("CourseID") int CourseID,
			@RequestParam("CourseName") String CourseName,
			@RequestParam("Description") String Description
	) throws SQLException{
		ModelAndView mv=new ModelAndView();
		String host= "jdbc:mysql://localhost/database";
		String UserName="root";
		String Pass="";
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		Connection connect1 =DriverManager.getConnection(host,UserName,Pass);
		 preparedStatement = connect1.prepareStatement("SELECT CourseID from course WHERE CourseName='"+CourseName+"'");
	      resultSet = preparedStatement.executeQuery();
	      try{
		      if (!resultSet.next() )
		      {
		    	  CourseDB.InsertCourse(CourseID, CourseName, Description);
		    	  mv.setViewName("ViewCourses");
			      }
			      else
			      {
			    	  mv.setViewName("CreateCourseError");
			    	  
			      }
		}catch (SQLException e){
			e.printStackTrace();
		}


		return mv;
	}
	/**
	 * purpose : Show all courses , and retrieve it from a database.
	 * @param :  No parameter.
	 * make an array list to retrieve the courses from a database .
     * @return : View Courses view (ViewCourse.html).
     */
	@RequestMapping("/Courses")
	public ModelAndView ViewRetriveCourses(){
		
		ArrayList<String> Courses= new ArrayList<String>();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ViewCourses");
		mv.addObject("ViewCourses",Courses);
		CourseDB.RetrieveCourses(Courses);

		
		return mv;
	}
	
	/**
	 * Purpose: Play Game in Math Course 
	 @param :  No parameter.
     * @return : Math view (Math.html).
	 */

	
	@RequestMapping("/Math")
	public ModelAndView viewMath()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Math");
		return mv;
	}
	/**
	 * Purpose: Play Game in Puzzle Course 
	 @param :  No parameter.
     * @return : Puzzle view (Puzzle.html).
	 */
	@RequestMapping("/Puzzle")
	public ModelAndView viewPuzzle()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Puzzle");
		return mv;
	}
	@RequestMapping("/FirstNewCourse")
	public ModelAndView viewFirstNewCourse()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("FirstNewCourse");
		return mv;
	}
	
	/**
	 * Purpose: Play Game in Programming Course 
	 @param :  No parameter.
     * @return : Programming view (Programming.html).
	 */
	@RequestMapping("/Programming")
	public ModelAndView viewProgramming()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Programming");
		return mv;
		
	}
	
	@RequestMapping("/NewCourse")
	public ModelAndView viewNewCourse()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("NewCourse");
		return mv;
		
	}

	
	
	@RequestMapping("/Game1")
	public ModelAndView ViewRetrievePuzzle1()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Game1");
		return mv;
	}
	
	@RequestMapping("/Game2")
	public ModelAndView ViewRetrievePuzzle2()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Game2");
		return mv;
	}
	
	@RequestMapping("/NewGame")
	public ModelAndView ViewNewGame()		
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("NewGame");
		return mv;
	}
	
	@RequestMapping("/AddQuestions")
	public ModelAndView InsertGameInSpecificCourse(
			@RequestParam("CourseID") int CourseID , 
			@RequestParam ("GameName") String GameName,
			@RequestParam ("NumberOfQuestion")  int NumberOfQuestion)
	{
		GameDB.InsertGame(CourseID, GameName, NumberOfQuestion);
		//QuestionAndAnswer QA= new QuestionAndAnswer();
		System.out.println("worked");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("AddQuestions");
		//mv.addObject("result", QA);
		return mv;
	}
	
	
	@RequestMapping("/InsertGame")
	public ModelAndView InsertQuestionsInSpecificGame(
			@RequestParam("GameName") String GameName , 
			@RequestParam ("Question") String Question,
			@RequestParam ("CorrectAnswer") String CorrectAnswer)
	{
		/*
		SELECT Number_Of_Question
		from `game`  , `add_new_game`
		where `game`.Game_Name = `add_new_game`.Game_Name
		*/
		NewGameDB.InsertNewGame(GameName, Question, CorrectAnswer);
		System.out.println("worked");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("AddQuestions");
		return mv;
	}
	
	

	
	
	
	/**
	 * purpose : Show Game from Game Database.
	 * @param : No Parameter
	 * @return : return all the Games stored in a database 
	 * related to specific course
	 */
	
	@RequestMapping("/ShowGame")
	public ModelAndView ViewRetrieveGame(){
		List Games= new ArrayList<String>();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		ModelAndView mv = new ModelAndView();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String host= "jdbc:mysql://localhost/gamedb";
		String UserName="root";
		String Pass="";
		try{
			Connection connect1 =(Connection) DriverManager.getConnection(host,UserName,Pass);
			preparedStatement = connect1
			          .prepareStatement("SELECT * from add_new_game  ");
			      resultSet = preparedStatement.executeQuery();
			      ResultSetMetaData rsmd = (ResultSetMetaData) resultSet.getMetaData();
			      int columnsNumber = rsmd.getColumnCount();
			      System.out.println(columnsNumber);
			      while (resultSet.next()) {
			          for (int i = 1; i <= columnsNumber; i+=6) {
			              String columnValue = resultSet.getString(i); 
			              Games.add(columnValue);
			          }
			       
			      }

		}catch (SQLException e){
			e.printStackTrace();
		}
		mv.setViewName("ShowGame");
		mv.addObject("Games",Games);
		
		return mv;
	}
	
	
	



}
