package Entity;

import java.util.ArrayList;

public class QuestionAndAnswer {
	public ArrayList<String>Questions;
	public ArrayList<String>Answers;
	public ArrayList<String>CorrectAnswers;
	public int numberOfQuestions;
	
	public QuestionAndAnswer(){}
	

}
