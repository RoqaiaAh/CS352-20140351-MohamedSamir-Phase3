package Entity;

public class Game {
	private int CourseID;
	private String GameName;
	private int NumberOfQuestion;

	public Game() {
		super();
		CourseID =0;
		GameName ="";
		NumberOfQuestion =0;
	}

	public Game(int courseID, String gameName, int numberOfQuestion) {
		super();
		CourseID = courseID;
		GameName = gameName;
		NumberOfQuestion = numberOfQuestion;
	}

	public int getCourseID() {
		return CourseID;
	}
	public void setCourseID(int courseID) {
		CourseID = courseID;
	}
	public String getGameName() {
		return GameName;
	}
	public void setGameName(String gameName) {
		GameName = gameName;
	}
	public int getNumberOfQuestion() {
		return NumberOfQuestion;
	}
	public void setNumberOfQuestion(int numberOfQuestion) {
		NumberOfQuestion = numberOfQuestion;
	}


}
