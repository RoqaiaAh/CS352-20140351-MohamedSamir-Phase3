package Entity;

public class User {
	private String Name;
    private String Password;
    private String Email;
    private String Type;
    
    public User()
    {
	}
    
	public User(String name, String password , String email , String type) {
		super();
		
		Name = name;
		Password = password;
		Email=email;
		Type=type;
		
	}
	public User(String name, String password ) {
		super();
		
		Name = name;
		Password = password;
		
		
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}
    
    


}
